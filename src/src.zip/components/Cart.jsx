import React from "react";
import "../styles/styles.css";

//importar componente Desayuno
import Desayuno from "./Desayuno";

import Cesta from '../img/cesta-compra.svg';

const Cart = ({ cart, setCart }) => {
    
  return (
    <div className="cart">
      <img src={Cesta} alt='Cesta'/>
      <h3>Carrito</h3>
      {cart.lenght === 0 ? (
        <p>0</p>
      ) : (
        cart.map((desayuno) => (
          <Desayuno
            key={desayuno.id}
            desayuno={desayuno}
            cart={cart}
            setCart={setCart}
          />
        ))
      )}
    </div>
  );
};

export default Cart;
